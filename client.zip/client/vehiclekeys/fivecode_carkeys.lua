CarKeys = {
    Give = function(veh, plate)
        TriggerServerEvent('fivecode_carkeys:pdmGiveKey', plate)
    end
}

return CarKeys