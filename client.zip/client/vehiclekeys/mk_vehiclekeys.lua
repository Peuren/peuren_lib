CarKeys = {
    Give = function(veh, plate)
        exports[Config.VehicleKeysResource]:AddKey(veh)
    end,
}

return CarKeys