CarKeys = {
    Give = function(veh, plate)
        TriggerServerEvent("okokGarage:GiveKeys", plate)
    end
}

return CarKeys